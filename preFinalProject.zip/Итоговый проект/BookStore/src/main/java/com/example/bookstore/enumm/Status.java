package com.example.bookstore.enumm;

public enum Status {
    Принят, Оформлен, Ожидает, Получен
}
